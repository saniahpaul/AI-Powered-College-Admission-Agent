# College Admission Agent — RAG Based

A student-friendly admission chatbot using Retrieval-Augmented Generation (RAG)
and IBM Granite through IBM watsonx.ai.

## Architecture

Student → Flask API → Retriever → Admission Documents → IBM Granite → Answer + Sources

## Important

The included admission handbook is DEMO DATA created for this project.
Replace it with official college documents before presenting real admission facts.

## Run locally

1. Open this folder in IBM Bob.
2. Create a Python virtual environment.
3. Install dependencies:

   pip install -r backend/requirements.txt

4. Copy `.env.example` to `.env`.
5. Add your IBM Cloud API key and watsonx.ai project ID.
6. Start:

   python backend/app.py

7. Open http://localhost:5000

## IBM Granite

The backend requests an IAM token using the IBM Cloud API key and calls the
watsonx.ai text generation endpoint with an IBM Granite model.

Do not commit `.env` or expose your API key.

## RAG

The demo retriever indexes paragraphs from `data/admission_documents`.
For a larger production implementation, replace the simple retriever with
an IBM-supported vector database / vector store and add PDF ingestion,
embeddings, metadata and document-level access controls.

## Demo questions

- What are the eligibility requirements?
- What is the B.Tech fee?
- What documents are required?
- What is the application deadline?
- Can diploma students apply?
- Are scholarships available?

## Presentation points

1. Problem: admission information is scattered and students ask repetitive questions.
2. Solution: retrieve trusted institutional information before generating an answer.
3. IBM Granite: generates the natural-language response.
4. RAG reduces hallucination by grounding responses in retrieved documents.
5. Sources are displayed with each answer.
