const form = document.getElementById("chatForm");
const input = document.getElementById("question");
const messages = document.getElementById("messages");

function addMessage(text, type, sources=[]) {
  const div = document.createElement("div");
  div.className = `message ${type}`;
  div.textContent = text;
  messages.appendChild(div);

  if (sources.length) {
    const sourceDiv = document.createElement("div");
    sourceDiv.className = "sources";
    sourceDiv.textContent = "Sources: " + sources.map(s => s.source).join(", ");
    messages.appendChild(sourceDiv);
  }
  messages.scrollTop = messages.scrollHeight;
}

async function ask(question) {
  addMessage(question, "user");
  input.value = "";
  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({question})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request failed");
    addMessage(data.answer, "bot", data.sources);
  } catch (e) {
    addMessage("Sorry, something went wrong: " + e.message, "bot");
  }
}

form.addEventListener("submit", e => {
  e.preventDefault();
  if (input.value.trim()) ask(input.value.trim());
});

document.querySelectorAll(".suggestions button").forEach(btn => {
  btn.addEventListener("click", () => ask(btn.textContent));
});
