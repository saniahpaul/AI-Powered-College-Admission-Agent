from pathlib import Path

def load_documents(directory: Path):
    docs = []
    for path in directory.glob("*"):
        if path.is_file() and path.suffix.lower() in {".txt", ".md"}:
            text = path.read_text(encoding="utf-8")
            paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
            for i, paragraph in enumerate(paragraphs, start=1):
                docs.append({
                    "source": path.name,
                    "chunk": i,
                    "text": paragraph
                })
    return docs
