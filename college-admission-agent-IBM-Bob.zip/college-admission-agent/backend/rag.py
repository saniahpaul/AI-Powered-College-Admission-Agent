import os
from pathlib import Path
from document_loader import load_documents
from embeddings import LocalRetriever
from granite import GraniteClient

DATA_DIR = Path(__file__).resolve().parent.parent / "data" / "admission_documents"

class AdmissionRAG:
    def __init__(self):
        self.documents = load_documents(DATA_DIR)
        self.retriever = LocalRetriever(self.documents)
        self.granite = GraniteClient()

    def answer(self, question: str):
        chunks = self.retriever.search(question, k=4)

        if not chunks:
            return {
                "answer": "I couldn't find this information in the admission documents.",
                "sources": []
            }

        context = "\n\n".join(
            f"[Source: {c['source']}]\n{c['text']}" for c in chunks
        )

        answer = self.granite.generate(question, context)
        return {
            "answer": answer,
            "sources": [{"source": c["source"], "text": c["text"][:350]} for c in chunks]
        }
