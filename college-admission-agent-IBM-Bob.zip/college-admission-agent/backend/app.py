import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from rag import AdmissionRAG

app = Flask(__name__, static_folder="../frontend", static_url_path="")
CORS(app)

rag = AdmissionRAG()

@app.get("/")
def home():
    return send_from_directory("../frontend", "index.html")

@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    if not question:
        return jsonify({"error": "Please enter a question."}), 400

    try:
        result = rag.answer(question)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "College Admission Agent"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=True)
