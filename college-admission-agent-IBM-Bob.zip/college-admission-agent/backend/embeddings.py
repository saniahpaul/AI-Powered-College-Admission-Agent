import re
import math
from collections import Counter

def tokenize(text):
    return re.findall(r"[a-zA-Z0-9]+", text.lower())

class LocalRetriever:
    """Small dependency-free TF-IDF-style retriever for the demo.
    It can later be replaced with an IBM/vector database retriever."""
    def __init__(self, documents):
        self.documents = documents
        self.vectors = [Counter(tokenize(d["text"])) for d in documents]

    def search(self, query, k=4):
        q = Counter(tokenize(query))
        scored = []
        for doc, vector in zip(self.documents, self.vectors):
            score = sum(q[t] * vector[t] for t in q)
            norm = math.sqrt(sum(v*v for v in vector.values())) or 1
            qnorm = math.sqrt(sum(v*v for v in q.values())) or 1
            score = score / (norm * qnorm)
            scored.append((score, doc))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [doc for score, doc in scored[:k] if score > 0]
