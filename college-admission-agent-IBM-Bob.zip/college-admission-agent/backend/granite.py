import os
import requests

class GraniteClient:
    def __init__(self):
        self.api_key = os.getenv("IBM_CLOUD_API_KEY")
        self.project_id = os.getenv("WATSONX_PROJECT_ID")
        self.url = os.getenv(
            "WATSONX_URL",
            "https://us-south.ml.cloud.ibm.com"
        )
        self.model_id = os.getenv(
            "GRANITE_MODEL_ID",
            "ibm/granite-4-h-small"
        )

    def generate(self, question, context):
        if not self.api_key or not self.project_id:
            return (
                "Demo mode: IBM Granite credentials are not configured yet.\n\n"
                f"Based on the retrieved admission information:\n{context}"
            )

        token_response = requests.post(
            "https://iam.cloud.ibm.com/identity/token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
                "apikey": self.api_key
            },
            timeout=30
        )
        token_response.raise_for_status()
        token = token_response.json()["access_token"]

        prompt = f"""You are a College Admission Agent.
Answer ONLY using the supplied context.
If the context does not contain the answer, say that the information
is not available in the provided admission documents.
Do not invent fees, dates, eligibility rules, or policies.

Context:
{context}

Student question:
{question}

Give a concise, student-friendly answer."""

        response = requests.post(
            f"{self.url}/ml/v1/text/generation?version=2024-03-19",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            },
            json={
                "model_id": self.model_id,
                "project_id": self.project_id,
                "input": prompt,
                "parameters": {
                    "max_new_tokens": 400,
                    "temperature": 0.2
                }
            },
            timeout=60
        )
        response.raise_for_status()
        data = response.json()
        return data["results"][0]["generated_text"].strip()
